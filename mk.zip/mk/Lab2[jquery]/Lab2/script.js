"use strict"

$(document).ready(function(){

	// $('button').click(function(){
	// 	alert($('input').val());
	// });

	// $('input').focus(function(){

	// 	$('p').html($(this).val());
	// });

	//$('input[type=text]').on('keyup', function(){
	//	$('.head1').html($(this).val());
	//});

	//$( function() {
    var availableTags = [
      "ActionScript",
      "AppleScript",
      "Asp",
      "BASIC",
      "C",
      "C++",
      "Clojure",
      "COBOL",
      "ColdFusion",
      "Erlang",
      "Fortran",
      "Groovy",
      "Haskell",
      "Java",
      "JavaScript",
      "Lisp",
      "Perl",
      "PHP",
      "Python",
      "Ruby",
      "Scala",
      "Scheme",
	  "MONJIRUL"
    ];
    $( "#auto" ).autocomplete({
      source: availableTags
    });
  //  });

});







