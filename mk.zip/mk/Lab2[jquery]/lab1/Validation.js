"use strict"

$(document).ready(function(){


   // $("#datepicker" ).datepicker();




    var availableTags = [
      "A+",
	  "O+",
	  "B+",
	  "AB+",
	  "O-",
	  "AB-"
    ];
    $("#BloodGroup" ).autocomplete({
      source: availableTags
    });
 
   
    
  
  
  
  

});







